
setwd('C:/Users/Lupyan Lab/Dropbox/CogSci/')

dataFile <- 'data_exp2_valid.csv'
df <- read.csv(dataFile, header=T)
df$cue <- ifelse(df$cueType=='sound',-0.5,0.5)
df$delay <- ifelse(df$delay=='simultaneous',-0.5,0.5)

df <- df[,c('subjCode','picFile','soundTypZ','labelTypZ','cue','delay','latency')]

require(lme4)
require(pbkrtest)
mod <- lmer(latency ~ (soundTypZ + labelTypZ)*cue*delay + 
              (cue*delay|subjCode) + (cue*delay|picFile), data=df)
summary(mod)

mod.smp1 <- lmer(latency ~ (soundTypZ + labelTypZ)*cue*delay - soundTypZ:cue:delay +
                   (cue*delay|subjCode) + (cue*delay|picFile), data=df)
memory.limit(size=12000)
KRmodcomp(mod, mod.smp1)