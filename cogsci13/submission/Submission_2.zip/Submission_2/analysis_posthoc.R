library(lme4)
library(psych)

########################
# Experiment 2 Results #
########################
dataPath <- '/Users/Lupyan Lab/Dropbox/CogSci/data_exp2_valid.csv'
df <- read.csv(dataPath, header=T)

########################
# fit a model predicting latency from the average of category and sound typicalities (overall typicality)
df$averageTyp <- rowMeans(df[,c('soundTypZ','labelTypZ')])
range(df[,c('soundTypZ','labelTypZ')])
range(df$averageTyp)

MOD2 <- lmer(latency ~ (soundTypZ + labelTypZ)*cueType*delay + (1|subjCode) + (1|picFile), data=df)

MOD.ave <- lmer(latency ~ averageTyp*cueType*delay + (1|subjCode) + (1|picFile), data=df)
summary(MOD.ave)

anova(MOD2, MOD.ave)

######################
# correlations between norming accuracy and response times
normPath <- 'C:/Users/Lupyan Lab/Dropbox/CogSci/data_exp2_soundnorm.csv'
norm <- read.csv(normPath, header=T)
norm <- norm[1:10,,1:4]

describe(norm[1:9,])

d <- merge(df, norm, by.x='cueCategory', by.y='category')
d$percent_correct <- ifelse(d$cueType=='sound',d$percent_correct,NaN)

cor(d[d$cueType=='sound' & d$cueCategory!='scissors','latency'],d[d$cueType=='sound' & d$cueCategory!='scissors','percent_correct'])

