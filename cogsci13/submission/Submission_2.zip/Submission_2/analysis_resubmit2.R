library(psych)
library(plyr)
library(lme4)
library(languageR)
library(AICcmodavg)
library(ggplot2)
library(car)

setwd('C:/Users/Lupyan Lab/Dropbox/CogSci/')
setwd('~/Dropbox/CogSci/')

source('helperFunctions-withinSubjErrors.R')

########################
# Experiment 1 Results #
########################
dataPath <- 'data_exp1_valid.csv'
df <- read.csv(dataPath, header=T)

# 
MOD1 <- lmer(latency ~ (labelTypZ + soundTypZ)*cueType + (1|subjCode) + (1|picName), data=df)
summary(MOD1)

df$cueType.label <- ifelse(df$cueType=='label',0,1)
MOD1.label <- lmer(latency ~ (labelTypZ + soundTypZ)*cueType.label + (1|subjCode) + (1|picName), data=df)
summary(MOD1.label)

df$cueType.sound <- ifelse(df$cueType=='sound',0,1)
MOD1.sound <- lmer(latency ~ (labelTypZ + soundTypZ)*cueType.sound + (1|subjCode) + (1|picName), data=df)
summary(MOD1.sound)

MOD <- lmer(latency ~ labelTypZ*soundTypZ*cueType + (1|subjCode) + (1|picName), data=df)
summary(MOD)

set.seed(101)
mcmc.MOD1 <- pvals.fnc(MOD1, nsim=10000, withMCMC=T)
mcmc.MOD1$fixed

df$cueTypeR <- factor(df$cueType,levels=c('sound','label'))
MOD1R <- lmer(latency ~ (labelTypZ + soundTypZ)*cueTypeR + (1|subjCode) + (1|picName), data=df)
summary(MOD1R)

set.seed(101)
mcmc.MOD1R <- pvals.fnc(MOD1R, nsim=10000, withMCMC=T)
mcmc.MOD1R$fixed

############
# Figure 2 #
############
# get the range for the typicalities (x-axis)
typicality_values = seq(round(min(c(min(df$labelTypZ),min(df$soundTypZ))), digits=1),
                        round(max(c(max(df$labelTypZ),max(df$soundTypZ))), digits=1), by=0.1)

# generate model predictions
preds_soundTyp <- expand.grid(soundTypZ=typicality_values, labelTypZ=0.0, cueType =c('label','sound'))
preds_soundTyp <- cbind(preds_soundTyp, 
                        predictSE.mer(mod=MOD, newdata=preds_soundTyp, type='link', print.matrix=T))

preds_soundTyp <- cbind(preds_soundTyp, 
                        predictSE.mer(mod=MOD1, newdata=preds_soundTyp, type='response', print.matrix=T))

preds_soundTyp$gradient <- 'soundMatch'

preds_labelTyp <- expand.grid(soundTypZ=0.0, labelTypZ=typicality_values, cueType=c('label','sound'))
preds_labelTyp <- cbind(preds_labelTyp, 
                        predictSE.mer(mod=MOD1, newdata=preds_labelTyp, type='link', print.matrix=T))
preds_labelTyp$gradient <- 'categoryTypicality'

preds <- rbind.data.frame(preds_soundTyp, preds_labelTyp)
preds$delay <- 'Delayed (1000 msec)'
preds$typicality <- ifelse(preds$gradient == 'soundMatch', preds$soundTypZ, preds$labelTypZ)
names(preds)[names(preds)=='fit' | names(preds)=='se.fit'] <- c('latency','se')
preds$upr <- preds$latency + preds$se
preds$lwr <- preds$latency - preds$se

# functions for modeling
labeller_exp1 <- function(var, value){
  value <- as.character(value)
  if (var=="gradient") { 
    value[value=="categoryTypicality"] <- "Category Typicality"
    value[value=="soundMatch"]   <- "Sound Match"
  }
  return(value)
}

theme_exp1 <- function(base_size = 12, base_family = "", ...){
  modifyList(theme_bw(base_size = base_size, base_family = base_family),
             list(legend.justification=c(1,1), legend.position=c(1,1), legend.title.align=0.5, legend.key=element_blank()))
}

main_effect <- expand.grid(cueType=c('label','sound'), 
                           gradient=c('categoryTypicality','soundMatch'),
                           delay='Delayed (1000 msec)',
                           latency=0,
                           se=0)
se_within <- summarySEwithin(data=df, measurevar='latency', 
                              betweenvars=NULL, withinvars='cueType', idvar='subjCode')
main_effect[main_effect$cueType=='label','se'] <- se_within[se_within$cueType=='label','se']
main_effect[main_effect$cueType=='sound','se'] <- se_within[se_within$cueType=='sound','se']
main_effect$typicality=0.0

main_effect[main_effect$cueType=='label' & main_effect$gradient=='categoryTypicality','latency'] <- 
  preds[preds$cueType=='label' & preds$gradient=='categoryTypicality' & preds$typicality==0.0, 'latency']
main_effect[main_effect$cueType=='label' & main_effect$gradient=='soundMatch','latency'] <- 
  preds[preds$cueType=='label' & preds$gradient=='soundMatch' & preds$typicality==0.0, 'latency']
main_effect[main_effect$cueType=='sound' & main_effect$gradient=='categoryTypicality','latency'] <- 
  preds[preds$cueType=='sound' & preds$gradient=='categoryTypicality' & preds$typicality==0.0, 'latency']
main_effect[main_effect$cueType=='sound' & main_effect$gradient=='soundMatch','latency'] <- 
  preds[preds$cueType=='sound' & preds$gradient=='soundMatch' & preds$typicality==0.0, 'latency']


yaxis <- seq(525,725,by=25)
g <- ggplot(preds, aes(x=typicality, y=latency, color=cueType, fill=cueType, linetype=cueType)) +
  geom_smooth(aes(ymin=lwr, ymax=upr), stat='identity', lwd=0.7) +
  geom_errorbar(aes(x=typicality, y=latency, ymin=latency-se, ymax=latency+se), data=main_effect, 
                width=0.4, stat='identity') +
  facet_grid(delay ~ gradient, labeller=labeller_exp1) +
  coord_cartesian(ylim = yaxis) +
  scale_x_continuous('Image Rating (z-scores)') +
  scale_y_continuous('Response Latency (msec)', breaks=yaxis) + 
  scale_color_manual('Cue Type', labels=c('Label','Sound'), values=c('red','blue')) +
  scale_linetype_manual('Cue Type', labels=c('Label','Sound'), values=c(1,2)) +
  scale_fill_grey('Cue Type', labels=c('Label','Sound'), start=0.6, end=0.8) +
  theme_exp1(base_size=24)
print(g)

# make and save the graph
#graphPath <- 'C:/Users/Lupyan Lab/Dropbox/CogSci/fig_exp1.png'
graphPath <- 'fig_exp1.png'
png(filename=graphPath, width=8, height=8, units='in', res=300)
print(g)
dev.off()

# -----------------------------------------------------------------
rm(list=ls())
########################
# Experiment 2 Results #
########################
# fit a model predicting latency from the average of category and sound typicalities (overall typicality)

# correlations between norming accuracy and response times

dataPath <- 'data_exp2_valid.csv'
df <- read.csv(dataPath, header=T)

MOD2 <- lmer(latency ~ (labelTypZ + soundTypZ)*cueType*delay + (1|subjCode) + (1|picFile), data=df)
summary(MOD2)
set.seed(102)
mcmc <- pvals.fnc(MOD2, nsim=10000, withMCMC=T)
mcmc$fixed

5.49^2
2.62^2 # interaction between cue type and delay
-3.21^2
############
# Figure 4 #
############
# predictions
preds_soundTyp <- expand.grid(soundTypZ=seq(-3.2,1.5,by=0.1), labelTypZ=0.0,
                              cueType=c('label','sound'), delay=c('simultaneous','delayed'))
preds_soundTyp <- cbind(preds_soundTyp, 
                        predictSE.mer(mod=MOD2, newdata=preds_soundTyp, type='link', print.matrix=T))
preds_soundTyp$gradient <- 'soundMatch'

preds_labelTyp <- expand.grid(soundTypZ=0.0, labelTypZ = seq(-3.2,1.5,by=0.1), 
                              cueType=c('label','sound'),  delay=c('simultaneous','delayed'))
preds_labelTyp <- cbind(preds_labelTyp, 
                        predictSE.mer(mod=MOD2, newdata=preds_labelTyp, type='link', print.matrix=T))
preds_labelTyp$gradient <- 'categoryTypicality'

preds <- rbind.data.frame(preds_soundTyp, preds_labelTyp)
preds$typicality <- ifelse(preds$gradient == 'soundMatch', preds$soundTypZ, preds$labelTypZ)
names(preds)[names(preds)=='fit' | names(preds)=='se.fit'] <- c('latency','se')
preds$upr <- preds$latency + preds$se
preds$lwr <- preds$latency - preds$se

theme_exp2 <- function(base_size = 12, base_family = "", ...){
  modifyList(theme_bw(base_size = base_size, base_family = base_family),
             list(legend.justification=c(0,0), legend.position=c(0,0), legend.title.align=0.5, legend.key=element_blank(),
                  legend.background = element_rect(fill=NA,color=NA)))
}

labeller_exp2 <- function(var, value){
  value <- as.character(value)
  if (var=="gradient") { 
    value[value=="categoryTypicality"] <- "Category Typicality"
    value[value=="soundMatch"]   <- "Sound Match"
  }
  if (var=="delay") {
    value[value=="simultaneous"] <- "Simultaneous"
    value[value=="delayed"] <- "Delayed (400 msec)"
  }
  return(value)
}

main_effect <- expand.grid(cueType=c('label','sound'), 
                           gradient=c('categoryTypicality','soundMatch'),
                           delay=c('delayed','simultaneous'),
                           latency=0,
                           se=0,
                           typicality=0)
se_within <- summarySEwithin(data=df, measurevar='latency', 
                             betweenvars=NULL, withinvars=c('cueType','delay'), idvar='subjCode')
se_within2 <- summarySEwithin(data=df, measurevar='latency', 
                             betweenvars=NULL, withinvars='cueType', idvar='subjCode')


main_effect[main_effect$cueType=='label' & main_effect$delay=='delayed','se'] <- 
  se_within[se_within$cueType=='label' & se_within$delay=='delayed','se']
main_effect[main_effect$cueType=='label' & main_effect$delay=='simultaneous','se'] <- 
  se_within[se_within$cueType=='label' & se_within$delay=='simultaneous','se']
main_effect[main_effect$cueType=='sound' & main_effect$delay=='delayed','se'] <- 
  se_within[se_within$cueType=='sound' & se_within$delay=='delayed','se']
main_effect[main_effect$cueType=='sound' & main_effect$delay=='simultaneous','se'] <- 
  se_within[se_within$cueType=='sound' & se_within$delay=='simultaneous','se']


main_effect[main_effect$cueType=='label' & main_effect$delay=='delayed' & 
              main_effect$gradient=='categoryTypicality','latency'] <- 
  preds[preds$cueType=='label' & preds$delay=='delayed' & 
          preds$gradient=='categoryTypicality' & preds$typicality==0.0, 'latency']

main_effect[main_effect$cueType=='label' & main_effect$delay=='simultaneous' & 
              main_effect$gradient=='categoryTypicality','latency'] <- 
  preds[preds$cueType=='label' & preds$delay=='simultaneous' & 
          preds$gradient=='categoryTypicality' & preds$typicality==0.0, 'latency']

main_effect[main_effect$cueType=='label' & main_effect$delay=='delayed' & 
              main_effect$gradient=='soundMatch','latency'] <- 
  preds[preds$cueType=='label' & preds$delay=='delayed' & 
          preds$gradient=='soundMatch' & preds$typicality==0.0, 'latency']

main_effect[main_effect$cueType=='label' & main_effect$delay=='simultaneous' & 
              main_effect$gradient=='soundMatch','latency'] <- 
  preds[preds$cueType=='label' & preds$delay=='simultaneous' & 
          preds$gradient=='soundMatch' & preds$typicality==0.0, 'latency']
##########################################################################
main_effect[main_effect$cueType=='sound' & main_effect$delay=='delayed' & 
              main_effect$gradient=='categoryTypicality','latency'] <- 
  preds[preds$cueType=='sound' & preds$delay=='delayed' & 
          preds$gradient=='categoryTypicality' & preds$typicality==0.0, 'latency']

main_effect[main_effect$cueType=='sound' & main_effect$delay=='simultaneous' & 
              main_effect$gradient=='categoryTypicality','latency'] <- 
  preds[preds$cueType=='sound' & preds$delay=='simultaneous' & 
          preds$gradient=='categoryTypicality' & preds$typicality==0.0, 'latency']

main_effect[main_effect$cueType=='sound' & main_effect$delay=='delayed' & 
              main_effect$gradient=='soundMatch','latency'] <- 
  preds[preds$cueType=='sound' & preds$delay=='delayed' & 
          preds$gradient=='soundMatch' & preds$typicality==0.0, 'latency']

main_effect[main_effect$cueType=='sound' & main_effect$delay=='simultaneous' & 
              main_effect$gradient=='soundMatch','latency'] <- 
  preds[preds$cueType=='sound' & preds$delay=='simultaneous' & 
          preds$gradient=='soundMatch' & preds$typicality==0.0, 'latency']
##########################################################################
yaxis <- seq(425,775,by=25)
yaxis <- yaxis[which(yaxis!=575)]

g <- ggplot(preds, aes(x=typicality, y=latency, color=cueType, fill=cueType, linetype=cueType)) +
  geom_smooth(aes(ymin=lwr, ymax=upr), lwd=0.7, stat='identity') +
  geom_errorbar(aes(x=typicality, y=latency, ymin=latency-se, ymax=latency+se), data=main_effect, 
                width=0.4, stat='identity') +
  facet_grid(delay ~ gradient, labeller=labeller_exp2, scales='free_y') +
  scale_x_continuous('Image Rating (z-scores)') +
  scale_y_continuous('Response Latency (msec)', breaks=yaxis) + 
  scale_color_manual('Cue Type', labels=c('Label','Sound'), values=c('red','blue')) +
  scale_linetype_manual('Cue Type', labels=c('Label','Sound'), values=c(1,2)) +
  scale_fill_grey('Cue Type', labels=c('Label','Sound'), start=0.6, end=0.8) +
  theme_exp2(base_size=24)
print(g)

# make and save the graph
graphPath <- 'fig_exp2_error.png'
png(filename=graphPath, width=8, height=14, units='in', res=300)
print(g)
dev.off()
