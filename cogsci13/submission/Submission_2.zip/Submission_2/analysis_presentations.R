library(psych)
library(plyr)
library(lme4)
library(languageR)
library(AICcmodavg)
library(ggplot2)
library(car)

setwd('C:/Users/Lupyan Lab/Dropbox/CogSci/')

########################
# Experiment 1 Results #
########################
dataPath <- 'data_exp1_valid.csv'
df <- read.csv(dataPath, header=T)


# model for generating predictions
MOD1 <- lmer(latency ~ (labelTypZ + soundTypZ)*cueType + (1|subjCode) + (1|picName), data=df)
summary(MOD1)

# get the range for the typicalities (x-axis)
typicality_values = seq(round(min(c(min(df$labelTypZ),min(df$soundTypZ))), digits=1),
                        round(max(c(max(df$labelTypZ),max(df$soundTypZ))), digits=1), by=0.1)

# generate model predictions
preds_soundTyp <- expand.grid(soundTypZ=typicality_values, labelTypZ=0.0, cueType=c('label','sound'))
preds_soundTyp <- cbind(preds_soundTyp, 
                        predictSE.mer(mod=MOD1, newdata=preds_soundTyp, type='link', print.matrix=T))
preds_soundTyp$gradient <- 'soundMatch'

preds_labelTyp <- expand.grid(soundTypZ=0.0, labelTypZ=typicality_values, cueType=c('label','sound'))
preds_labelTyp <- cbind(preds_labelTyp, 
                        predictSE.mer(mod=MOD1, newdata=preds_labelTyp, type='link', print.matrix=T))
preds_labelTyp$gradient <- 'categoryTypicality'

preds <- rbind.data.frame(preds_soundTyp, preds_labelTyp)
preds$delay <- 'Delayed (600 msec)'
preds$typicality <- ifelse(preds$gradient == 'soundMatch', preds$soundTypZ, preds$labelTypZ)
names(preds)[names(preds)=='fit' | names(preds)=='se.fit'] <- c('latency','se')
preds$upr <- preds$latency + preds$se
preds$lwr <- preds$latency - preds$se

# functions for modeling
labeller_exp1 <- function(var, value){
  value <- as.character(value)
  if (var=="gradient") { 
    value[value=="categoryTypicality"] <- "Category Typicality"
    value[value=="soundMatch"]   <- "Sound Match"
  }
  return(value)
}

theme_exp1 <- function(base_size = 12, base_family = "", ...){
  modifyList(theme_bw(base_size = base_size, base_family = base_family),
             list(legend.justification=c(1,1), legend.position=c(1,1), legend.title.align=0.5, legend.key=element_blank()))
}

yaxis <- seq(525,725,by=25)

# make and save the graph
graphPath <- 'presentation/exp1.bmp'
bmp(filename=graphPath, width=10, height=8, units='in', res=300)
ggplot(preds, 
       aes(x=typicality, y=latency, color=cueType, fill=cueType, linetype=cueType)) +
  geom_smooth(aes(ymin=lwr, ymax=upr), stat='identity', lwd=0.7) +
  facet_grid(delay ~ gradient, labeller=labeller_exp1, drop=TRUE) +
  coord_cartesian(ylim = yaxis) +
  scale_x_continuous('Image Rating (z-scores)') +
  scale_y_continuous('Response Latency (msec)', breaks=yaxis) + 
  scale_color_manual('Cue Type', labels=c('Label','Sound'), values=c('red','blue')) +
  scale_linetype_manual('Cue Type', labels=c('Label','Sound'), values=c(1,2)) +
  scale_fill_grey('Cue Type', labels=c('Label','Sound'), start=0.6, end=0.8) +
  theme_exp1(base_size=24)
dev.off()

graphPath <- 'presentation/exp1_categoryTyp.bmp'
bmp(filename=graphPath, width=6, height=8, units='in', res=300)
ggplot(preds[preds$gradient=='categoryTypicality',], 
       aes(x=typicality, y=latency, color=cueType, fill=cueType, linetype=cueType)) +
  geom_smooth(aes(ymin=lwr, ymax=upr), stat='identity', lwd=0.7) +
  facet_grid(delay ~ gradient, labeller=labeller_exp1, drop=TRUE) +
  coord_cartesian(ylim = yaxis) +
  scale_x_continuous('Image Rating (z-scores)') +
  scale_y_continuous('Response Latency (msec)', breaks=yaxis) + 
  scale_color_manual('Cue Type', labels=c('Label','Sound'), values=c('red','blue')) +
  scale_linetype_manual('Cue Type', labels=c('Label','Sound'), values=c(1,2)) +
  scale_fill_grey('Cue Type', labels=c('Label','Sound'), start=0.6, end=0.8) +
  theme_exp1(base_size=24)
dev.off()

graphPath <- 'presentation/exp1_soundMatch.bmp'
bmp(filename=graphPath, width=6, height=8, units='in', res=300)
ggplot(preds[preds$gradient=='soundMatch',], 
       aes(x=typicality, y=latency, color=cueType, fill=cueType, linetype=cueType)) +
  geom_smooth(aes(ymin=lwr, ymax=upr), stat='identity', lwd=0.7) +
  facet_grid(delay ~ gradient, labeller=labeller_exp1, drop=TRUE) +
  coord_cartesian(ylim = yaxis) +
  scale_x_continuous('Image Rating (z-scores)') +
  scale_y_continuous('Response Latency (msec)', breaks=yaxis) + 
  scale_color_manual('Cue Type', labels=c('Label','Sound'), values=c('red','blue')) +
  scale_linetype_manual('Cue Type', labels=c('Label','Sound'), values=c(1,2)) +
  scale_fill_grey('Cue Type', labels=c('Label','Sound'), start=0.6, end=0.8) +
  theme_exp1(base_size=24)
dev.off()

# -----------------------------------------------------------------
rm(list=ls())
########################
# Experiment 2 Results #
########################
dataPath <- 'data_exp2_valid.csv'
df <- read.csv(dataPath, header=T)

MOD2 <- lmer(latency ~ (labelTypZ + soundTypZ)*cueType*delay + (1|subjCode) + (1|picFile), data=df)

############
# Figure 4 #
############
# predictions
preds_soundTyp <- expand.grid(soundTypZ=seq(-3.2,1.5,by=0.1), labelTypZ=0.0,
                              cueType=c('label','sound'), delay=c('simultaneous','delayed'))
preds_soundTyp <- cbind(preds_soundTyp, 
                        predictSE.mer(mod=MOD2, newdata=preds_soundTyp, type='link', print.matrix=T))
preds_soundTyp$gradient <- 'soundMatch'

preds_labelTyp <- expand.grid(soundTypZ=0.0, labelTypZ = seq(-3.2,1.5,by=0.1), 
                              cueType=c('label','sound'),  delay=c('simultaneous','delayed'))
preds_labelTyp <- cbind(preds_labelTyp, 
                        predictSE.mer(mod=MOD2, newdata=preds_labelTyp, type='link', print.matrix=T))
preds_labelTyp$gradient <- 'categoryTypicality'

preds <- rbind.data.frame(preds_soundTyp, preds_labelTyp)
preds$typicality <- ifelse(preds$gradient == 'soundMatch', preds$soundTypZ, preds$labelTypZ)
names(preds)[names(preds)=='fit' | names(preds)=='se.fit'] <- c('latency','se')
preds$upr <- preds$latency + preds$se
preds$lwr <- preds$latency - preds$se

theme_exp2 <- function(base_size = 12, base_family = "", ...){
  modifyList(theme_bw(base_size = base_size, base_family = base_family),
             list(legend.justification=c(0,0), legend.position=c(0,0), legend.title.align=0.5, legend.key=element_blank(),
                  legend.background = element_rect(fill=NA,color=NA)))
}

labeller_exp2 <- function(var, value){
  value <- as.character(value)
  if (var=="gradient") { 
    value[value=="categoryTypicality"] <- "Category Typicality"
    value[value=="soundMatch"]   <- "Sound Match"
  }
  if (var=="delay") {
    value[value=="simultaneous"] <- "Simultaneous"
    value[value=="delayed"] <- "Delayed (400 msec)"
  }
  return(value)
}

yaxis <- seq(425,775,by=25)
yaxis <- yaxis[which(yaxis!=575)]

# make and save the graph
graphPath <- 'presentation/exp2.bmp'
bmp(filename=graphPath, width=10, height=16, units='in', res=300)
ggplot(preds, 
       aes(x=typicality, y=latency, color=cueType, fill=cueType, linetype=cueType)) +
  geom_smooth(aes(ymin=lwr, ymax=upr), lwd=0.7, stat='identity') +
  facet_grid(delay ~ gradient, labeller=labeller_exp2, scales='free_y', drop=TRUE) +
  scale_x_continuous('Image Rating (z-scores)') +
  scale_y_continuous('Response Latency (msec)', breaks=yaxis) + 
  scale_color_manual('Cue Type', labels=c('Label','Sound'), values=c('red','blue')) +
  scale_linetype_manual('Cue Type', labels=c('Label','Sound'), values=c(1,2)) +
  scale_fill_grey('Cue Type', labels=c('Label','Sound'), start=0.6, end=0.8) +
  theme_exp2(base_size=24)
dev.off()


graphPath <- 'presentation/exp2_delayed.bmp'
bmp(filename=graphPath, width=10, height=8, units='in', res=300)
ggplot(preds[preds$delay=='delayed',], 
       aes(x=typicality, y=latency, color=cueType, fill=cueType, linetype=cueType)) +
  geom_smooth(aes(ymin=lwr, ymax=upr), lwd=0.7, stat='identity') +
  facet_grid(delay ~ gradient, labeller=labeller_exp2, scales='free_y', drop=TRUE) +
  scale_x_continuous('Image Rating (z-scores)') +
  scale_y_continuous('Response Latency (msec)', breaks=yaxis) + 
  scale_color_manual('Cue Type', labels=c('Label','Sound'), values=c('red','blue')) +
  scale_linetype_manual('Cue Type', labels=c('Label','Sound'), values=c(1,2)) +
  scale_fill_grey('Cue Type', labels=c('Label','Sound'), start=0.6, end=0.8) +
  theme_exp2(base_size=24)
dev.off()

graphPath <- 'presentation/exp2_delayed_categoryTyp.bmp'
bmp(filename=graphPath, width=6, height=8, units='in', res=300)
ggplot(preds[preds$delay=='delayed' & preds$gradient=='categoryTypicality',], 
       aes(x=typicality, y=latency, color=cueType, fill=cueType, linetype=cueType)) +
  geom_smooth(aes(ymin=lwr, ymax=upr), lwd=0.7, stat='identity') +
  facet_grid(delay ~ gradient, labeller=labeller_exp2, scales='free_y', drop=TRUE) +
  scale_x_continuous('Image Rating (z-scores)') +
  scale_y_continuous('Response Latency (msec)', breaks=yaxis) + 
  scale_color_manual('Cue Type', labels=c('Label','Sound'), values=c('red','blue')) +
  scale_linetype_manual('Cue Type', labels=c('Label','Sound'), values=c(1,2)) +
  scale_fill_grey('Cue Type', labels=c('Label','Sound'), start=0.6, end=0.8) +
  theme_exp2(base_size=24)
dev.off()

graphPath <- 'presentation/exp2_delayed_soundMatch.bmp'
bmp(filename=graphPath, width=6, height=8, units='in', res=300)
ggplot(preds[preds$delay=='delayed' & preds$gradient=='soundMatch',], 
       aes(x=typicality, y=latency, color=cueType, fill=cueType, linetype=cueType)) +
  geom_smooth(aes(ymin=lwr, ymax=upr), lwd=0.7, stat='identity') +
  facet_grid(delay ~ gradient, labeller=labeller_exp2, scales='free_y', drop=TRUE) +
  scale_x_continuous('Image Rating (z-scores)') +
  scale_y_continuous('Response Latency (msec)', breaks=yaxis) + 
  scale_color_manual('Cue Type', labels=c('Label','Sound'), values=c('red','blue')) +
  scale_linetype_manual('Cue Type', labels=c('Label','Sound'), values=c(1,2)) +
  scale_fill_grey('Cue Type', labels=c('Label','Sound'), start=0.6, end=0.8) +
  theme_exp2(base_size=24)
dev.off()

graphPath <- 'presentation/exp2_simult.bmp'
bmp(filename=graphPath, width=10, height=8, units='in', res=300)
ggplot(preds[preds$delay=='simultaneous',], 
       aes(x=typicality, y=latency, color=cueType, fill=cueType, linetype=cueType)) +
  geom_smooth(aes(ymin=lwr, ymax=upr), lwd=0.7, stat='identity') +
  facet_grid(delay ~ gradient, labeller=labeller_exp2, scales='free_y', drop=TRUE) +
  scale_x_continuous('Image Rating (z-scores)') +
  scale_y_continuous('Response Latency (msec)', breaks=yaxis) + 
  scale_color_manual('Cue Type', labels=c('Label','Sound'), values=c('red','blue')) +
  scale_linetype_manual('Cue Type', labels=c('Label','Sound'), values=c(1,2)) +
  scale_fill_grey('Cue Type', labels=c('Label','Sound'), start=0.6, end=0.8) +
  theme_exp2(base_size=24)
dev.off()

graphPath <- 'presentation/exp2_simult_categoryTyp.bmp'
bmp(filename=graphPath, width=6, height=8, units='in', res=300)
ggplot(preds[preds$delay=='simultaneous' & preds$gradient=='categoryTypicality',], 
       aes(x=typicality, y=latency, color=cueType, fill=cueType, linetype=cueType)) +
  geom_smooth(aes(ymin=lwr, ymax=upr), lwd=0.7, stat='identity') +
  facet_grid(delay ~ gradient, labeller=labeller_exp2, scales='free_y', drop=TRUE) +
  scale_x_continuous('Image Rating (z-scores)') +
  scale_y_continuous('Response Latency (msec)', breaks=yaxis) + 
  scale_color_manual('Cue Type', labels=c('Label','Sound'), values=c('red','blue')) +
  scale_linetype_manual('Cue Type', labels=c('Label','Sound'), values=c(1,2)) +
  scale_fill_grey('Cue Type', labels=c('Label','Sound'), start=0.6, end=0.8) +
  theme_exp2(base_size=24)
dev.off()

graphPath <- 'presentation/exp2_simult_soundMatch.bmp'
bmp(filename=graphPath, width=6, height=8, units='in', res=300)
ggplot(preds[preds$delay=='simultaneous' & preds$gradient=='soundMatch',], 
       aes(x=typicality, y=latency, color=cueType, fill=cueType, linetype=cueType)) +
  geom_smooth(aes(ymin=lwr, ymax=upr), lwd=0.7, stat='identity') +
  facet_grid(delay ~ gradient, labeller=labeller_exp2, scales='free_y', drop=TRUE) +
  scale_x_continuous('Image Rating (z-scores)') +
  scale_y_continuous('Response Latency (msec)', breaks=yaxis) + 
  scale_color_manual('Cue Type', labels=c('Label','Sound'), values=c('red','blue')) +
  scale_linetype_manual('Cue Type', labels=c('Label','Sound'), values=c(1,2)) +
  scale_fill_grey('Cue Type', labels=c('Label','Sound'), start=0.6, end=0.8) +
  theme_exp2(base_size=24)
dev.off()
