library(psych)

#' Data Checks
#' - bad images
#' - bad sound files
#' - bad subjects

setwd('~/Dropbox/CogSci/')

#############################
# Experiment 1 Norming Data #
#############################
dataFile <- 'data_exp1_norming.csv'
norm <- read.csv(dataFile, header=T)

cor(norm[,c('zTypLabels','zTypSounds')])
cor(norm[,c('meanTypLabels','meanTypSounds')])

describeBy(norm[,c('meanTypLabels','meanTypSounds')], norm$objType)

############################
# Experiment 1 Data Checks #
############################
#dataFile <- "~/Documents/Apps/CogSci/Submission_2013/data_exp1.csv"
dataFile <- 'C:/Users/Lupyan Lab/Dropbox/CogSci/data_exp1.csv'
data <- read.csv(file=dataFile,header=TRUE)

# overall accuracy
mean(data$isRight)
sd(data$isRight)

# check for bad images
picFileAccs <- list()
for(file in unique(data$picName)){
  picFileAccs[file] <- mean(data[data$picName==file,'isRight'])
}
picFileAccs = as.data.frame(unlist(picFileAccs))
names(picFileAccs) <- 'accuracy'
describe(picFileAccs)
row.names(picFileAccs)[picFileAccs$accuracy < mean(picFileAccs$accuracy)-3*sd(picFileAccs$accuracy)]
# no bad pics

# check for bad sounds
soundFileAccs <- list()
for(file in unique(data$soundName)){
  soundFileAccs[file] <- mean(data[data$soundName==file,'isRight'])
}
soundFileAccs = as.data.frame(unlist(soundFileAccs))
names(soundFileAccs) <- 'accuracy'
describe(soundFileAccs)
row.names(soundFileAccs)[soundFileAccs$accuracy < mean(soundFileAccs$accuracy)-3*sd(soundFileAccs$accuracy)]
soundFileAccs['river_sound',] # accuracy of river_sound
length(data[data$soundName=='river_sound','isRight'])/length(data$isRight) # % trials removed
  # bad sound files: river_sound, don't remove

# check for bad subjs
subjAccs <- list()
for(subj in unique(data$subjCode)){
  subjAccs[subj] <- mean(data[data$subjCode==subj,'isRight'])
}
subjAccs = as.data.frame(unlist(subjAccs))
names(subjAccs) <- 'accuracy'
describe(subjAccs)
row.names(subjAccs)[subjAccs$accuracy < mean(subjAccs$accuracy) - 3*sd(subjAccs$accuracy)]
# no bad subjs

# subset the full data
sum(is.na(data[data$isRight==1,'latency']))/length(data$latency) # < 4% of trials thrown (<250 or >1500)
valid <- na.omit(subset(data, isValid==1, realOrPractice!='practice')) # don't throw any trials by stimuli
keep <- names(valid)[!(names(valid) %in% c('X','gender','resposneMap','feedback','rt','realOrPractice'))] 
valid <- valid[,keep]

dataPath <- '/Users/Lupyan Lab/Dropbox/CogSci/data_exp1_valid.csv'
write.table(valid, dataPath, sep=',') # write out the valid data
rm(list = ls())

# ------------------------------------------------------------------------------------------------------ 
#############################
# Experiment 2 Norming Data #
#############################
dataFile <- 'C:/Users/Lupyan Lab/Dropbox/CogSci/data_exp2_norming.csv'
norm <- read.csv(dataFile, header=T)

cor(norm[,c('zScore_label','zScore_sound')])
cor(norm[norm$picCat == 'bird',c('zScore_label','zScore_sound')])
by(norm[,c('zScore_label','zScore_sound')],norm$picCat,cor)


############################
# Experiment 2 Data Checks #
############################
#dataFile <- "~/Documents/Apps/CogSci/Submission_2013/data_exp2.csv"
dataFile <- 'C:/Users/Lupyan Lab/Dropbox/CogSci/data_exp2.csv'
data <- read.csv(file=dataFile, header=T)

# overall accuracy
mean(data$isRight)
sd(data$isRight)

# check for bad pics
picFileAccs <- list()
for(file in unique(data$picFile)){
  picFileAccs[file] <- mean(data[data$picFile==file,'isRight'])
}
picFileAccs = as.data.frame(unlist(picFileAccs))
names(picFileAccs) <- 'accuracy'
describe(picFileAccs)
row.names(picFileAccs)[picFileAccs$accuracy < mean(picFileAccs$accuracy) - 3*sd(picFileAccs$accuracy)]
# no bad pics

# check for bad stimuli
soundFileAccs <- list()
for(file in unique(data$soundFile)){
  soundFileAccs[file] <- mean(data[data$soundFile==file,'isRight'])
}
soundFileAccs = as.data.frame(unlist(soundFileAccs))
names(soundFileAccs) <- 'accuracy'
describe(soundFileAccs)
row.names(soundFileAccs)[soundFileAccs$accuracy < mean(soundFileAccs$accuracy) - 3*sd(soundFileAccs$accuracy)]
length(data[data$soundFile=='scissors_sound','isRight'])/length(data$isRight) # % trials removed
  # remove scissors_sound trials

# check for bad subjs
subjAccs <- list()
for(subj in unique(data$subjCode)){
  subjAccs[subj] <- mean(data[data$subjCode==subj,'isRight'])
}
subjAccs = as.data.frame(unlist(subjAccs))
colnames(subjAccs) <- 'accuracy'
describe(subjAccs)
row.names(subjAccs)[subjAccs$accuracy < mean(subjAccs$accuracy) - 3*sd(subjAccs$accuracy)]
mean(data[data$subjCode=='TYP1_122','isRight']) # bad participant, but don't throw

# subset the full data
sum(is.na(data[data$isRight == 1 & data$soundFile != 'scissors_sound','latency']))/length(data$latency) # < 2% trials thrown (<250 or >1500)
valid <- na.omit(subset(data, whichPart != 'practice' & isMatch == 1 & soundFile != 'scissors_sound'))
valid$delay <- factor(valid$soa, levels=c(0,1), labels=c('simultaneous','delayed'))
keep <- names(valid)[!(names(valid) %in% c('X','seed','responseDevice','data','room','initials','exp','date',
                                           'rt','expTimer','soa','whichPart'))] 
valid <- valid[,keep]

dataPath <- '/Users/Lupyan Lab/Dropbox/CogSci/data_exp2_valid.csv'
write.table(valid, dataPath, sep=',') # write out the valid data
