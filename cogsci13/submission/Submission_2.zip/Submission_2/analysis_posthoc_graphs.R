library(lme4)
library(AICcmodavg)
library(ggplot2)

# get data
dataPath <- 'C:/Users/Lupyan Lab/Dropbox/CogSci/data_exp2.csv'
df <- read.csv(dataPath, header=T)

# functions for labeling facets
labeller <- function(var, value){
  value <- as.character(value)
  if (var=="gradient") { 
    value[value=="categoryTypicality"] <- "Category Typicality"
    value[value=="soundMatch"]   <- "Sound Match"
  }
  if (var=="delay") {
    value[value=="simultaneous"] <- "Simultaneous"
    value[value=="delayed"] <- "Delayed (400 msec)"
  }
  return(value)
}


# get the range for the typicalities (x-axis)
typicality_values = seq(round(min(c(min(df$labelTypZ),min(df$soundTypZ))), digits=1),
                        round(max(c(max(df$labelTypZ),max(df$soundTypZ))), digits=1), by=0.1)

graphBy <- function(column, var) {
  d.sub <- subset(df, df[,column]==var)
  MOD <- lmer(latency ~ (labelTypZ + soundTypZ)*cueType + (1|subjCode) + (1|picFile), data=d.sub)
  
  preds_soundTyp <- expand.grid(soundTypZ=seq(-3.2,1.5,by=0.1), labelTypZ=0.0,
                                cueType=c('label','sound'), delay=c('simultaneous','delayed'))
  preds_soundTyp <- cbind(preds_soundTyp, 
                          predictSE.mer(mod=MOD, newdata=preds_soundTyp, type='link', print.matrix=T))
  preds_soundTyp$gradient <- 'soundMatch'
  
  preds_labelTyp <- expand.grid(soundTypZ=0.0, labelTypZ = seq(-3.2,1.5,by=0.1), 
                                cueType=c('label','sound'),  delay=c('simultaneous','delayed'))
  preds_labelTyp <- cbind(preds_labelTyp, 
                          predictSE.mer(mod=MOD, newdata=preds_labelTyp, type='link', print.matrix=T))
  preds_labelTyp$gradient <- 'categoryTypicality'
  
  preds <- rbind.data.frame(preds_soundTyp, preds_labelTyp)
  preds$typicality <- ifelse(preds$gradient == 'soundMatch', preds$soundTypZ, preds$labelTypZ)
  names(preds)[names(preds)=='fit' | names(preds)=='se.fit'] <- c('latency','se')
  preds$upr <- preds$latency + preds$se
  preds$lwr <- preds$latency - preds$se
    
  yaxis <- seq(425,775,by=25)
  
  # make and save the graph
  graphPath <- paste0('C:/Users/Lupyan Lab/Dropbox/CogSci/extra_graphs/',column,'_',var,'.png')
  png(filename=graphPath, width=8, height=14, units='in', res=300)
  g <- ggplot(preds, aes(x=typicality, y=latency, color=cueType, fill=cueType, linetype=cueType)) +
    geom_smooth(aes(ymin=lwr, ymax=upr), lwd=0.7, stat='identity') +
    facet_grid(delay ~ gradient, labeller=labeller, scales='free_y') +
    scale_x_continuous('Image Rating (z-scores)') +
    scale_y_continuous('Response Latency (msec)', breaks=yaxis) + 
    scale_color_manual('Cue Type', labels=c('Label','Sound'), values=c('red','blue')) +
    scale_linetype_manual('Cue Type', labels=c('Label','Sound'), values=c(1,2)) +
    scale_fill_grey('Cue Type', labels=c('Label','Sound'), start=0.6, end=0.8)
  print(g)
  dev.off()
}

column <- 'picCategory'
for (var in unique(df[,column])) {
  if (var != 'scissors') {
    graphBy(column, var)
  }
  else {
    print(paste0('Skipping: ',var))
  }
}

column <- 'picAnimate'
for (var in unique(df[,column])) {
  graphBy(column, var)
}
