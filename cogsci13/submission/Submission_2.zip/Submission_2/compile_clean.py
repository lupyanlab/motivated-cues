import os, glob
import numpy as np
import pandas as pd
from pandas import DataFrame, Series

def compile(headerFile,key):
	colNames = [col.strip('\n\r').split('\t') for col in open(headerFile)][0]
	dfs = []
	for file in glob.glob('*.txt'):
		if file != headerFile and file.find(key) != -1:
			try:
				subj = pd.read_table(file, sep='\t', header=None, index_col=False, names=colNames)
				dfs.append(subj)
			except:
				print "Error reading file: "+file
	return pd.concat(dfs, ignore_index=True)

def clean(df,min=250,max=1500,sds=3,practice=('whichPart','practice')):
	if sds == -1: sds = 10
	(min,max,sds) = map(float,(min,max,sds))
	def cutoff( df ):
		return df['latency'] > df['latency'].mean() + ( sds*df['latency'].std() )
	df['latency'] = df['rt']
	lessThan = ((df['rt'] < min) & (df['isRight'] == 1)).sum()
	greaterThan = ((df['rt'] > max) & (df['isRight'] == 1)).sum()
	print '\n# Bad trials #\n%s less than %s\n%s greater than %s' % (lessThan, min, greaterThan, max)
	df['latency'][ (df['isRight'] == 0) | (df[practice[0]] == practice[1]) | (df['rt'] < min) | (df['rt'] > max) ] = np.nan
	df['latency'][df.groupby('subjCode').apply(cutoff) == 1] = np.nan
	
	return df

def clean_data(headerFile,output,key=''):
	df = compile(headerFile,key)
	df = clean(df)
	df.to_csv(output,na_rep='NaN')

def check_stims(df,col,sds=2.5):
	sds = float(sds)
	
	def accuracy( df ):
		return df['isRight'].mean()
	
	ser = df.groupby(col).apply(accuracy)
	accs = DataFrame([ser, ser>(ser.mean() - sds*ser.std())]).T
	accs.columns=['accByStim','isNormal']
	print '\n# Accuracy more than %s stds below M=%s(SD=%s) #\n' % (sds,ser.mean(),ser.std())
	print accs[:][accs['isNormal'] == False]

def merge_norming(df, valsFile):
	vals = pd.read_csv(valsFile)
	df['soundTyp'] = np.nan
	df['labelTyp'] = np.nan
	for file, trials in df.groupby('picName'):
		df['soundTyp'][ df['picName'] == file ] = vals['meanTypSounds'][ vals['fileName'] == file ]
		df['labelTyp'][ df['picName'] == file ] = vals['meanTypLabels'][ vals['fileName'] == file ]


''' Merge norming data for stimulus materials
'''
def merge_norming(df,vals):
	# create the file names as a new column vals
	df['soundTyp'] = np.nan
	df['soundTypZ'] = np.nan
	df['labelTyp'] = np.nan
	df['labelTypZ'] = np.nan
	for fileName in df['picFile'].unique():
		mSeries1 = vals['mean_sound'][vals['fileName']==fileName]
		df['soundTyp'][ df['picFile'] == fileName ] = mSeries1[mSeries1.index[0]]
		zSeries1 = vals['zScore_sound'][vals['fileName']==fileName]
		df['soundTypZ'][ df['picFile'] == fileName ] = zSeries1[zSeries1.index[0]]
		
		mSeries2 = vals['mean_label'][vals['fileName']==fileName]
		df['labelTyp'][ df['picFile'] == fileName ] = mSeries2[mSeries2.index[0]]
		zSeries2 = vals['zScore_label'][vals['fileName']==fileName]
		df['labelTypZ'][ df['picFile'] == fileName ] = zSeries2[zSeries2.index[0]]
	df.to_csv('data_exp2.csv')

