library(psych)
library(plyr)
library(lme4)
library(languageR)
library(AICcmodavg)
library(ggplot2)
library(car)

setwd('C:/Users/Lupyan Lab/Dropbox/CogSci/')
setwd('~/Dropbox/CogSci/')

####################################################################################



# first set up the factors that are the same for all plots
##########################################################
# facet plot labeller
labeller <- function(var, value){
  value <- as.character(value)
  if (var=="gradient") { 
    value[value=="categoryTypicality"] <- "Category Typicality"
    value[value=="soundMatch"]   <- "Sound Match"
  }
  if (var=="delay") {
    value[value=="simultaneous"] <- "Simultaneous"
    value[value=="delayed"] <- "Delayed (400 msec)"
  }
  if (var=="delay_exp1") {
    value[value=="delayed"] <- "Delayed (1000 msec)"
  }
  return(value)
}

theme_exp1 <- function(base_size = 12, base_family = "", ...){
  modifyList(theme_bw(base_size = base_size, base_family = base_family),
             list(legend.justification=c(1,1), legend.position=c(1,1), 
                  legend.title.align=0.5, legend.key=element_blank()))
}
theme_exp2 <- function(base_size = 12, base_family = "", ...) {
  modifyList(theme_bw(base_size = base_size, base_family = base_family),
             list(legend.justification=c(0,0), legend.position=c(0,0), 
                  legend.title.align=0.5, legend.key=element_blank(),
                  legend.background = element_rect(fill=NA,color=NA)))
}

# plot data for experiment 1 normally
#####################################
dataPath <- 'data_exp1_valid.csv'
df <- read.csv(dataPath, header=T)

# get x values for plots
typicality_values = seq(round(min(c(min(df$labelTypZ),min(df$soundTypZ))), digits=1),
                        round(max(c(max(df$labelTypZ),max(df$soundTypZ))), digits=1), by=0.1)

# get model for model predictions
MOD1 <- lmer(latency ~ (labelTypZ + soundTypZ)*cueType + (1|subjCode) + (1|picName), data=df)
summary(MOD1)

# generate predictions
preds_soundTyp <- expand.grid(soundTypZ=typicality_values, labelTypZ=0.0, cueType =c('label','sound'))
preds_soundTyp <- cbind(preds_soundTyp, 
                        predictSE.mer(mod=MOD1, newdata=preds_soundTyp, type='link', print.matrix=T))
preds_soundTyp$gradient <- 'soundMatch'

preds_labelTyp <- expand.grid(soundTypZ=0.0, labelTypZ=typicality_values, cueType=c('label','sound'))
preds_labelTyp <- cbind(preds_labelTyp, 
                        predictSE.mer(mod=MOD1, newdata=preds_labelTyp, type='link', print.matrix=T))
preds_labelTyp$gradient <- 'categoryTypicality'

preds <- rbind.data.frame(preds_soundTyp, preds_labelTyp)
preds$delay_exp1 <- 'delayed'
preds$typicality <- ifelse(preds$gradient == 'soundMatch', preds$soundTypZ, preds$labelTypZ)
names(preds)[names(preds)=='fit' | names(preds)=='se.fit'] <- c('latency','confInt')

# get the error bands
preds$upr <- preds$latency + preds$confInt
preds$lwr <- preds$latency - preds$confInt

# make the graph
yaxis <- seq(525,725,by=25)
g <- ggplot(preds, aes(x=typicality, y=latency, color=cueType, fill=cueType, linetype=cueType)) +
  geom_smooth(aes(ymin=lwr, ymax=upr), stat='identity', lwd=0.7) +
  facet_grid(delay_exp1 ~ gradient, labeller=labeller) +
  coord_cartesian(ylim = yaxis) +
  scale_x_continuous('Image Rating (z-scores)') +
  scale_y_continuous('Response Latency (msec)', breaks=yaxis) + 
  scale_color_manual('Cue Type', labels=c('Label','Sound'), values=c('red','blue')) +
  scale_linetype_manual('Cue Type', labels=c('Label','Sound'), values=c(1,2)) +
  scale_fill_grey('Cue Type', labels=c('Label','Sound'), start=0.6, end=0.8) +
  theme_exp1(base_size=24)
print(g)

graphPath <- 'errorbands/exp1_pointestimates.bmp'
bmp(filename=graphPath, width=8, height=8, units='in', res=300)
print(g)
dev.off()

# plot data for exp1 with within subjects errors by cue type
############################################################
# get within subjects errors
source('helperFunctions-withinSubjErrors.R')
within_errors_byCue <- summarySEwithin(data=df, measurevar='latency', 
                              betweenvars=NULL, withinvars='cueType', idvar='subjCode')

within_errors_byAll <- summarySEwithin(data=df, measurevar='latency', 
                                       betweenvars=NULL, withinvars=c('soundTypZ','labelTypZ','cueType'), 
                                       idvar='subjCode')
describe(within_errors_byAll)
describe(preds$se.fit)

# add the errors by cue type
preds <- rbind.data.frame(preds_soundTyp, preds_labelTyp)
preds$se_within <- ifelse(preds$cueType=='sound', within_errors_byCue[within_errors_byCue$cueType=='sound','se'],
                          within_errors_byCue[within_errors_byCue$cueType=='label','se'])

preds$delay_exp1 <- 'delayed'
preds$typicality <- ifelse(preds$gradient == 'soundMatch', preds$soundTypZ, preds$labelTypZ)
names(preds)[names(preds)=='fit'] <- 'latency'

preds$upr <- preds$latency + preds$se_within
preds$lwr <- preds$latency - preds$se_within

# make the graph
yaxis <- seq(525,725,by=25)
g <- ggplot(preds, aes(x=typicality, y=latency, color=cueType, fill=cueType, linetype=cueType)) +
  geom_smooth(aes(ymin=lwr, ymax=upr), stat='identity', lwd=0.7) +
  facet_grid(delay_exp1 ~ gradient, labeller=labeller) +
  coord_cartesian(ylim = yaxis) +
  scale_x_continuous('Image Rating (z-scores)') +
  scale_y_continuous('Response Latency (msec)', breaks=yaxis) + 
  scale_color_manual('Cue Type', labels=c('Label','Sound'), values=c('red','blue')) +
  scale_linetype_manual('Cue Type', labels=c('Label','Sound'), values=c(1,2)) +
  scale_fill_grey('Cue Type', labels=c('Label','Sound'), start=0.6, end=0.8) +
  theme_exp1(base_size=24)
print(g)

graphPath <- 'errorbands/exp1_withinbycue.bmp'
bmp(filename=graphPath, width=8, height=8, units='in', res=300)
print(g)
dev.off()

# plot data for exp2 with within subjects errors by cue type
############################################################
dataPath <- 'data_exp2_valid.csv'
df <- read.csv(dataPath, header=T)

MOD2 <- lmer(latency ~ (labelTypZ + soundTypZ)*cueType*delay + (1|subjCode) + (1|picFile), data=df)

# predictions
preds_soundTyp <- expand.grid(soundTypZ=seq(-3.2,1.5,by=0.1), labelTypZ=0.0,
                              cueType=c('label','sound'), delay=c('simultaneous','delayed'))
preds_soundTyp <- cbind(preds_soundTyp, 
                        predictSE.mer(mod=MOD2, newdata=preds_soundTyp, type='link', print.matrix=T))
preds_soundTyp$gradient <- 'soundMatch'

preds_labelTyp <- expand.grid(soundTypZ=0.0, labelTypZ = seq(-3.2,1.5,by=0.1), 
                              cueType=c('label','sound'),  delay=c('simultaneous','delayed'))
preds_labelTyp <- cbind(preds_labelTyp, 
                        predictSE.mer(mod=MOD2, newdata=preds_labelTyp, type='link', print.matrix=T))
preds_labelTyp$gradient <- 'categoryTypicality'

# get the within subject errors by cue
within_errors_byCue <- summarySEwithin(data=df, measurevar='latency', 
                                       betweenvars=NULL, withinvars='cueType', idvar='subjCode')

# add the errors by cue type
preds <- rbind.data.frame(preds_soundTyp, preds_labelTyp)
preds$se_within <- ifelse(preds$cueType=='sound', within_errors_byCue[within_errors_byCue$cueType=='sound','se'],
                          within_errors_byCue[within_errors_byCue$cueType=='label','se'])

preds$typicality <- ifelse(preds$gradient == 'soundMatch', preds$soundTypZ, preds$labelTypZ)
names(preds)[names(preds)=='fit'] <- 'latency'
preds$upr <- preds$latency + preds$se_within
preds$lwr <- preds$latency - preds$se_within

yaxis <- seq(425,775,by=25)
yaxis <- yaxis[which(yaxis!=575)]
g <- ggplot(preds, aes(x=typicality, y=latency, color=cueType, fill=cueType, linetype=cueType)) +
  geom_smooth(aes(ymin=lwr, ymax=upr), lwd=0.7, stat='identity') +
  facet_grid(delay ~ gradient, labeller=labeller, scales='free_y') +
  scale_x_continuous('Image Rating (z-scores)') +
  scale_y_continuous('Response Latency (msec)', breaks=yaxis) + 
  scale_color_manual('Cue Type', labels=c('Label','Sound'), values=c('red','blue')) +
  scale_linetype_manual('Cue Type', labels=c('Label','Sound'), values=c(1,2)) +
  scale_fill_grey('Cue Type', labels=c('Label','Sound'), start=0.6, end=0.8) +
  theme_exp2(base_size=24)
print(g)

graphPath <- 'errorbands/exp2_withinbycue.bmp'
bmp(filename=graphPath, width=8, height=16, units='in', res=300)
print(g)
dev.off()

# plot data for exp1 with within subjects errors by cue type and by typicality
##############################################################################
# generate predictions
preds_soundTyp <- expand.grid(soundTypZ=typicality_values, labelTypZ=0.0, cueType =c('label','sound'))
preds_soundTyp <- cbind(preds_soundTyp, 
                        predictSE.mer(mod=MOD1, newdata=preds_soundTyp, type='link', print.matrix=T))
preds_soundTyp$gradient <- 'soundMatch'

preds_labelTyp <- expand.grid(soundTypZ=0.0, labelTypZ=typicality_values, cueType=c('label','sound'))
preds_labelTyp <- cbind(preds_labelTyp, 
                        predictSE.mer(mod=MOD1, newdata=preds_labelTyp, type='link', print.matrix=T))
preds_labelTyp$gradient <- 'categoryTypicality'

# get within subjects errors
source('helperFunctions-withinSubjErrors.R')
within_errors_byCue <- summarySEwithin(data=df, measurevar='latency', 
                                       betweenvars=NULL, withinvars=c('cueType','soundTypZ','labelTypZ'), 
                                       idvar='subjCode')

# add the errors by cue type
preds <- rbind.data.frame(preds_soundTyp, preds_labelTyp)
preds$se_within <- 
preds$se_within <- ifelse(preds$cueType=='sound', within_errors_byCue[within_errors_byCue$cueType=='sound','se'],
                          within_errors_byCue[within_errors_byCue$cueType=='label','se'])

preds$delay_exp1 <- 'delayed'
preds$typicality <- ifelse(preds$gradient == 'soundMatch', preds$soundTypZ, preds$labelTypZ)
names(preds)[names(preds)=='fit'] <- 'latency'

preds$upr <- preds$latency + preds$se_within
preds$lwr <- preds$latency - preds$se_within

# make the graph
yaxis <- seq(525,725,by=25)
g <- ggplot(preds, aes(x=typicality, y=latency, color=cueType, fill=cueType, linetype=cueType)) +
  geom_smooth(aes(ymin=lwr, ymax=upr), stat='identity', lwd=0.7) +
  facet_grid(delay_exp1 ~ gradient, labeller=labeller) +
  coord_cartesian(ylim = yaxis) +
  scale_x_continuous('Image Rating (z-scores)') +
  scale_y_continuous('Response Latency (msec)', breaks=yaxis) + 
  scale_color_manual('Cue Type', labels=c('Label','Sound'), values=c('red','blue')) +
  scale_linetype_manual('Cue Type', labels=c('Label','Sound'), values=c(1,2)) +
  scale_fill_grey('Cue Type', labels=c('Label','Sound'), start=0.6, end=0.8) +
  theme_exp1(base_size=24)
print(g)

graphPath <- 'errorbands/exp1_withinbycue.bmp'
bmp(filename=graphPath, width=8, height=8, units='in', res=300)
print(g)
dev.off()

#####

dev.off()
# get within subjects errors
source('helperFunctions-withinSubjErrors.R')
within_errors_byCue <- summarySEwithin(data=df, measurevar='latency', 
                                       betweenvars=NULL, withinvars='cueType', idvar='subjCode')

# add the errors by cue type
preds <- rbind.data.frame(preds_soundTyp, preds_labelTyp)
preds$se_within <- ifelse(preds$cueType=='sound', within_errors_byCue[within_errors_byCue$cueType=='sound','se'],
                          within_errors_byCue[within_errors_byCue$cueType=='label','se'])

preds$delay_exp1 <- 'delayed'
preds$typicality <- ifelse(preds$gradient == 'soundMatch', preds$soundTypZ, preds$labelTypZ)
names(preds)[names(preds)=='fit'] <- 'latency'

preds$upr <- preds$latency + preds$se_within
preds$lwr <- preds$latency - preds$se_within

# make the graph
yaxis <- seq(525,725,by=25)
g <- ggplot(preds, aes(x=typicality, y=latency, color=cueType, fill=cueType, linetype=cueType)) +
  geom_smooth(aes(ymin=lwr, ymax=upr), stat='identity', lwd=0.7) +
  facet_grid(delay_exp1 ~ gradient, labeller=labeller) +
  coord_cartesian(ylim = yaxis) +
  scale_x_continuous('Image Rating (z-scores)') +
  scale_y_continuous('Response Latency (msec)', breaks=yaxis) + 
  scale_color_manual('Cue Type', labels=c('Label','Sound'), values=c('red','blue')) +
  scale_linetype_manual('Cue Type', labels=c('Label','Sound'), values=c(1,2)) +
  scale_fill_grey('Cue Type', labels=c('Label','Sound'), start=0.6, end=0.8) +
  theme_exp1(base_size=24)
print(g)

graphPath <- 'errorbands/exp1_withinbycue.bmp'
bmp(filename=graphPath, width=8, height=8, units='in', res=300)
print(g)
dev.off()


dataPath <- 'data_exp2_valid.csv'
df <- read.csv(dataPath, header=T)

MOD2 <- lmer(latency ~ (labelTypZ + soundTypZ)*cueType*delay + (1|subjCode) + (1|picFile), data=df)
summary(MOD2)
set.seed(102)
mcmc <- pvals.fnc(MOD2, nsim=10000, withMCMC=T)
mcmc$fixed

############
# Figure 4 #
############
# predictions
preds_soundTyp <- expand.grid(soundTypZ=seq(-3.2,1.5,by=0.1), labelTypZ=0.0,
                              cueType=c('label','sound'), delay=c('simultaneous','delayed'))
preds_soundTyp <- cbind(preds_soundTyp, 
                        predictSE.mer(mod=MOD2, newdata=preds_soundTyp, type='link', print.matrix=T))
preds_soundTyp$gradient <- 'soundMatch'

preds_labelTyp <- expand.grid(soundTypZ=0.0, labelTypZ = seq(-3.2,1.5,by=0.1), 
                              cueType=c('label','sound'),  delay=c('simultaneous','delayed'))
preds_labelTyp <- cbind(preds_labelTyp, 
                        predictSE.mer(mod=MOD2, newdata=preds_labelTyp, type='link', print.matrix=T))
preds_labelTyp$gradient <- 'categoryTypicality'

preds <- rbind.data.frame(preds_soundTyp, preds_labelTyp)
preds$typicality <- ifelse(preds$gradient == 'soundMatch', preds$soundTypZ, preds$labelTypZ)
names(preds)[names(preds)=='fit' | names(preds)=='se.fit'] <- c('latency','se')
preds$upr <- preds$latency + preds$se
preds$lwr <- preds$latency - preds$se



yaxis <- seq(425,775,by=25)
yaxis <- yaxis[which(yaxis!=575)]

# make and save the graph
graphPath <- '/Users/Lupyan Lab/Dropbox/CogSci/fig_exp2.png'
png(filename=graphPath, width=8, height=14, units='in', res=300)
ggplot(preds, aes(x=typicality, y=latency, color=cueType, fill=cueType, linetype=cueType)) +
  geom_smooth(aes(ymin=lwr, ymax=upr), lwd=0.7, stat='identity') +
  facet_grid(delay ~ gradient, labeller=labeller_exp2, scales='free_y') +
  scale_x_continuous('Image Rating (z-scores)') +
  scale_y_continuous('Response Latency (msec)', breaks=yaxis) + 
  scale_color_manual('Cue Type', labels=c('Label','Sound'), values=c('red','blue')) +
  scale_linetype_manual('Cue Type', labels=c('Label','Sound'), values=c(1,2)) +
  scale_fill_grey('Cue Type', labels=c('Label','Sound'), start=0.6, end=0.8) +
  theme_exp2(base_size=24)
dev.off()



predsByCue <- summarySEwithin(data=df, measurevar='latency', 
                              betweenvars=NULL, withinvars=c('cueType','soundTypZ','labelTypZ'), idvar='subjCode')


MOD1 <- lmer(latency ~ (labelTypZ + soundTypZ)*cueType + (1|subjCode) + (1|picName), data=df)
summary(MOD1)

df$cue.sound <- ifelse(df$cueType=='sound',0,1)
MOD.sound <- lmer(latency ~ (labelTypZ + soundTypZ)*cue.sound + (1|subjCode) + (1|picName), data=df)
summary(MOD.sound)

df$cue.label <- ifelse(df$cueType=='label',0,1)
MOD.label <- lmer(latency ~ (labelTypZ + soundTypZ)*cue.label + (1|subjCode) + (1|picName), data=df)
summary(MOD.label)

