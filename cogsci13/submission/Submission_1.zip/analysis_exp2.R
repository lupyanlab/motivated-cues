library(languageR)
library(lme4)
library(plyr)
library(ggplot2)
library(doBy)
library(AICcmodavg)
source('~/Documents/Apps/CogSci/Submission_2013/helperFunctions-withinSubjErrors.R')

#' ###################
#' Fig. 3A and Fig. 3B
#' ###################

## get the norming data
normDatFile <- "~/Documents/Apps/CogSci/Submission_2013/data_exp2_norming.csv"
normDat <- read.csv(file=normDatFile,header=TRUE)

## graph the blank version (to paste the images on for Fig. 3A)
ggplot(normDat, aes(x=zScore_label, y=zScore_sound, col=picType)) + 
  geom_point(size = 10) +
  scale_color_manual(element_blank(), breaks=c('sound','both','neither','label'), 
                     labels=c('Sound','Both','Neither','Label'),
                     values=c(0,0,0,0)) +
  coord_cartesian(ylim=c(-2.2,2.2),xlim=c(-2.8,2.2)) +
  scale_x_discrete('More Category Typical', breaks=NULL) +
  scale_y_discrete('Better Match to Sound', breaks=NULL) +
  theme_bw(base_size=24) +
  theme(axis.text.y = element_text(angle=90, vjust=0.5)) + 
  annotate("segment", x=-2.7,xend=2.0,y=-2.1,yend=-2.1,arrow=arrow()) +
  annotate("segment", x=-2.7,xend=-2.7,y=-2.1,yend=2.1,arrow=arrow()) +
  theme(legend.position = 'none',
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        panel.border = element_blank())

## graph the color version with the real data
ggplot(normDat, aes(x=zScore_label, y=zScore_sound, col=picType, shape=picType)) + 
  geom_point(size = 10) +
  scale_color_manual(element_blank(), breaks=c('sound','both','neither','label'), 
                     labels=c('Sound','High','Low','Label'),
                     values=c(6,2,3,4)) +
  scale_shape_manual(element_blank(), breaks=c('sound','both','neither','label'), 
                     labels=c('Sound','High','Low','Label'),
                     values=c(16,17,18,15)) +
  coord_cartesian(ylim=c(-2.2,2.2),xlim=c(-2.8,2.2)) +
  scale_x_discrete('Better Fit to Category', breaks=NULL) +
  scale_y_discrete('Better Fit to Sound', breaks=NULL) +
  theme_bw(base_size=24) +
  theme(axis.text.y = element_text(angle=90, vjust=0.5)) + 
  annotate("segment", x=-2.7,xend=2.0,y=-2.1,yend=-2.1,arrow=arrow()) +
  annotate("segment", x=-2.7,xend=-2.7,y=-2.1,yend=2.1,arrow=arrow()) +
  annotate("segment", x=-2.7,xend=1.9,y=0,yend=0, linetype='dashed') +
  annotate("segment", x=0,xend=0,y=-2.1,yend=1.9, linetype='dashed') +
  theme(legend.position = c(0.5,0.93), 
        legend.direction = "horizontal",
        legend.key = element_blank(),
        legend.background = element_rect(fill="gray90"),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        panel.border = element_blank())

#' #################
#' Experiment 2 Data
#' #################
dataFile <- "~/Documents/Apps/CogSci/Submission_2013/data_exp2.csv"
data <- read.csv(file=dataFile,header=TRUE)

## overall accuracy
mean(data$isRight)
sd(data$isRight)

## check for bad pics
picFileAccs <- list()
for(file in unique(data$picFile)){
  picFileAccs[file] <- mean(data[data$picFile==file,'isRight'])
}
picFileAccs = as.data.frame(unlist(picFileAccs))
colnames(picFileAccs) <- 'accuracy'
describe(picFileAccs)
row.names(picFileAccs)[picFileAccs$accuracy < mean(picFileAccs$accuracy) - 3*sd(picFileAccs$accuracy)]

## check for bad stimuli
soundFileAccs <- list()
for(file in unique(data$soundFile)){
  soundFileAccs[file] <- mean(data[data$soundFile==file,'isRight'])
}
soundFileAccs = as.data.frame(unlist(soundFileAccs))
colnames(soundFileAccs) <- 'accuracy'
describe(soundFileAccs)
row.names(soundFileAccs)[soundFileAccs$accuracy < mean(soundFileAccs$accuracy) - 3*sd(soundFileAccs$accuracy)]
length(data[data$soundFile=='scissors_sound','isRight'])/length(data$isRight) # % trials removed

## check for bad subjs
subjAccs <- list()
for(subj in unique(data$subjCode)){
  subjAccs[subj] <- mean(data[data$subjCode==subj,'isRight'])
}
subjAccs = as.data.frame(unlist(subjAccs))
colnames(subjAccs) <- 'accuracy'
describe(subjAccs)
row.names(subjAccs)[subjAccs$accuracy < mean(subjAccs$accuracy) - 3*sd(subjAccs$accuracy)]
mean(data[data$subjCode=='TYP1_122','isRight']) # bad participant, but don't throw

## subset the full data
sum(is.na(data[data$isRight == 1 & data$soundFile != 'scissors_sound','latency']))/length(data$latency) # < 2% trials thrown (<250 or >1500)
df <- na.omit(subset(data, isMatch == 1 & soundFile != 'scissors_sound'))

#' ########
#' MOD.base
#' ########

## predict latency from soa, cuetype
MOD.base <- lmer(latency ~ soa * cueType + (1|subjCode) + (1|cueCategory), data = df)

## overall efects
summary(MOD.base)
anova(MOD.base)

## generate p-vals
set.seed(101)
mcmc.base <- pvals.fnc(MOD.base, nsim=1000, withMCMC=TRUE)
mcmc.base$fixed

## calculate means for main effects
predsBySOA <- summarySEwithin(data = df, measurevar = 'latency',
                              betweenvars = NULL, withinvars = 'soa',
                              idvar = 'subjCode')
predsByCue <- summarySEwithin(data = df, measurevar = 'latency',
                              betweenvars = NULL, withinvars = 'cueType',
                              idvar = 'subjCode')

#' #########
#' Figure 4A
#' #########

## generate predictions and errors
df$cueTypeR  <- factor(df$cueType, levels=rev(levels(df$cueType)) )

preds.base <- summarySEwithin(data = df, measurevar = 'latency',
                              betweenvars = NULL, withinvars = c('soa','cueTypeR'),
                              idvar = 'subjCode')
## compute label advantage at soa=0
preds.base[preds.base$soa == 0 & preds.base$cueType == 'sound','latencyNormed'] -
  preds.base[preds.base$soa == 0 & preds.base$cueType == 'label','latencyNormed']

## compute label advantage at soa=1
preds.base[preds.base$soa == 1 & preds.base$cueType == 'sound','latencyNormed'] -
  preds.base[preds.base$soa == 1 & preds.base$cueType == 'label','latencyNormed']

ggplot(preds.base, aes(x=soa, y=latencyNormed, fill=cueTypeR)) +
  geom_bar(width = 0.6, position = position_dodge(width=0.7), 
           color="black", stat='identity') +
  geom_errorbar(position=position_dodge(width=0.7), width=.25, aes(ymin=latencyNormed-ci, ymax=latencyNormed+ci)) +
  coord_cartesian(ylim=c(400,800)) +
  scale_fill_manual('Auditory Cue', labels = c('Natural Sound','Label'), values=c('blue','red')) +
  scale_y_continuous('Response Latency (msec)',breaks=seq(400,800,by=50)) +
  scale_x_discrete('Image Delay', labels = c('0' = 'Simultaneous','1'='400 msec')) +
  theme_bw(base_size=24) +
  theme(legend.position = c(0.5,0.9), legend.direction = "horizontal") + 
  guides(fill=guide_legend(title=NULL))

#' #####################
#' MOD.catTyp:
#' Predict latency from labelTypZ, soa, cueType
#' Random effects: subjCode and cueCategory
#' #####################
MOD.catTyp <- lmer(latency ~ labelTypZ * soa * cueType + (1|subjCode) + (1|cueCategory), data = df)

## model comparison
anova(MOD.base,MOD.catTyp) # how do I report this?

## check collinearity
kappa.mer(MOD.catTyp) # < 30 O.K.

## overall efects
summary(MOD.catTyp)
anova(MOD.catTyp)

## generate p-vals
set.seed(101)
mcmc.catTyp <- pvals.fnc(MOD.catTyp, nsim=1000, withMCMC=TRUE)
mcmc.catTyp$fixed

#' #################
#' Figure 4B:
#' #################

## get the predictions
preds.X <- expand.grid(labelTypZ = seq(-2.2,1.5,by=0.5),
                       soa = c(0,1),
                       cueType = c('label','sound'))
preds.Y <- as.data.frame(predictSE.mer(mod=MOD.catTyp, newdata=preds.X, type='link', print.matrix=TRUE))
preds.Y$ci.u <- preds.Y$fit + preds.Y$se.fit
preds.Y$ci.l <- preds.Y$fit - preds.Y$se.fit

## make the graph
par(mfrow=c(1,2), mar=c(2,0,2,1)+0.1, oma=c(2,5,2,0)+0.1)

## LEFT GRAPH: Simultaneous
plot(x=df$labelTypZ, y=df$latency, type='n', main='Simultaneous',
     ylim=range(600,800), yaxt='n', xlim=range(-2.2,1.5), xaxt='n', bty='n')
axis(side=2,at=seq(600,800,by=50),labels=seq(600,800,by=50),tick=TRUE,line=1)
axis(side=1,at=c(-1.5,0,1.5),labels=c(-1.5,0,1.5),tick=TRUE,line=NA)
rug(df$labelTypZ)

select <- (preds.X$soa == 0 & preds.X$cueType == 'sound')
lines(preds.X[select,'labelTypZ'], preds.Y[select,'fit'], col='blue', lwd=2, lty=2)
lines(preds.X[select,'labelTypZ'], preds.Y[select,'ci.u'], col='gray')
lines(preds.X[select,'labelTypZ'], preds.Y[select,'ci.l'], col='gray')

select <- (preds.X$soa == 0 & preds.X$cueType == 'label')
lines(preds.X[select,'labelTypZ'], preds.Y[select,'fit'], col='red', lwd=2)
lines(preds.X[select,'labelTypZ'], preds.Y[select,'ci.u'], col='gray')
lines(preds.X[select,'labelTypZ'], preds.Y[select,'ci.l'], col='gray')
mtext('Response Latency (msec)',side=2,padj=-4.5,cex=1.2)

## RIGHT GRAPH: 1 Sec Delay
plot(x=df$labelTypZ, y=df$latency, type='n', main='400 msec Delay',
     ylim=range(400,600), yaxt='n', xlim=range(-2.2,1.5), xaxt='n', bty='n')
axis(side=2,at=seq(400,600,by=50),labels=seq(400,600,by=50),tick=TRUE,line=NA)
axis(side=1,at=c(-1.5,0,1.5),labels=c(-1.5,0,1.5),tick=TRUE,line=NA)
rug(df$labelTypZ)

legend("topright",inset=0.01, title="Auditory Cue",
       c('Natural Sound','Label'), col=c('blue','red'), horiz=FALSE,
       lty=c(2,1), lwd=c(3,3), bty='n')

select <- (preds.X$soa == 1 & preds.X$cueType == 'sound')
lines(preds.X[select,'labelTypZ'], preds.Y[select,'fit'], col='blue', lwd=2, lty=2)
lines(preds.X[select,'labelTypZ'], preds.Y[select,'ci.u'], col='gray')
lines(preds.X[select,'labelTypZ'], preds.Y[select,'ci.l'], col='gray')

select <- (preds.X$soa == 1 & preds.X$cueType == 'label')
lines(preds.X[select,'labelTypZ'], preds.Y[select,'fit'], col='red', lwd=2)
lines(preds.X[select,'labelTypZ'], preds.Y[select,'ci.u'], col='gray')
lines(preds.X[select,'labelTypZ'], preds.Y[select,'ci.l'], col='gray')
mtext('Image Fit to Category (z-scores)',side=1,outer=TRUE,padj=-0.2,cex=1.2)

#' #####################
#' MOD.picFit:
#' Predict latency from soundTypZ, soa, and cueType
#' Random effects: subjCode and cueCategory
#' #####################
MOD.picFit <- lmer(latency ~ soundTypZ * soa * cueType + (1|subjCode) + (1|cueCategory), data = df)

## model comparison to base model
anova(MOD.base,MOD.picFit) # do I report this?

## check collinearity
kappa.mer(MOD.picFit) # < 30 O.K.

## overall efects
summary(MOD.picFit)
anova(MOD.picFit)

## generate p-vals
set.seed(101)
mcmc.picFit <- pvals.fnc(MOD.picFit, nsim=1000, withMCMC=TRUE)
mcmc.picFit$fixed


df$soaR  <- ifelse(df$soa == 1, 0, -1)
MOD.picFitR <- lmer(latency ~ soundTypZ * soaR * cueType + (1|subjCode) + (1|cueCategory), data = df)
summary(MOD.picFitR)
anova(MOD.picFitR)
set.seed(101)
mcmc.picFitR <- pvals.fnc(MOD.picFitR, nsim=1000, withMCMC=TRUE)
mcmc.picFitR$fixed

#' ##############
#' Figure 4C:
#' ##############

## get the predictions
preds.X <- expand.grid(soundTypZ = seq(-2.2,1.5,by=0.5),
                       soa = c(0,1),
                       cueType = c('label','sound'))
preds.Y <- as.data.frame(predictSE.mer(mod=MOD.picFit, newdata=preds.X, type='link', print.matrix=TRUE))
preds.Y$ci.u <- preds.Y$fit + preds.Y$se.fit
preds.Y$ci.l <- preds.Y$fit - preds.Y$se.fit

## make the graph
par(mfrow=c(1,2), mar=c(2,0,2,1)+0.1, oma=c(2,5,2,0)+0.1)

## LEFT GRAPH: Simultaneous
plot(x=df$soundTypZ, y=df$latency, type='n', main='Simultaneous',
     ylim=range(600,800), yaxt='n', xlim=range(-2.2,1.5), xaxt='n', bty='n')
axis(side=2,at=seq(600,800,by=50),labels=seq(600,800,by=50),tick=TRUE,line=1)
axis(side=1,at=c(-1.5,0,1.5),labels=c(-1.5,0,1.5),tick=TRUE,line=NA)
rug(df$soundTypZ)

select <- (preds.X$soa == 0 & preds.X$cueType == 'sound')
lines(preds.X[select,'soundTypZ'], preds.Y[select,'fit'], col='blue', lwd=2, lty=2)
lines(preds.X[select,'soundTypZ'], preds.Y[select,'ci.u'], col='gray')
lines(preds.X[select,'soundTypZ'], preds.Y[select,'ci.l'], col='gray')

select <- (preds.X$soa == 0 & preds.X$cueType == 'label')
lines(preds.X[select,'soundTypZ'], preds.Y[select,'fit'], col='red', lwd=2)
lines(preds.X[select,'soundTypZ'], preds.Y[select,'ci.u'], col='gray')
lines(preds.X[select,'soundTypZ'], preds.Y[select,'ci.l'], col='gray')
mtext('Response Latency (msec)',side=2,padj=-4.5,cex=1.2)

## RIGHT GRAPH: 1 Sec Delay
plot(x=df$soundTypZ, y=df$latency, type='n', main='400 msec Delay',
     ylim=range(400,600), yaxt='n', xlim=range(-2.2,1.5), xaxt='n', bty='n')
axis(side=2,at=seq(400,600,by=50),labels=seq(400,600,by=50),tick=TRUE,line=NA)
axis(side=1,at=c(-1.5,0,1.5),labels=c(-1.5,0,1.5),tick=TRUE,line=NA)
rug(df$soundTypZ)

legend("topright",inset=0.01, title="Auditory Cue",
       c('Natural Sound','Label'), col=c('blue','red'), horiz=FALSE,
       lty=c(2,1), lwd=c(3,3), bty='n')

select <- (preds.X$soa == 1 & preds.X$cueType == 'sound')
lines(preds.X[select,'soundTypZ'], preds.Y[select,'fit'], col='blue', lwd=2, lty=2)
lines(preds.X[select,'soundTypZ'], preds.Y[select,'ci.u'], col='gray')
lines(preds.X[select,'soundTypZ'], preds.Y[select,'ci.l'], col='gray')

select <- (preds.X$soa == 1 & preds.X$cueType == 'label')
lines(preds.X[select,'soundTypZ'], preds.Y[select,'fit'], col='red', lwd=2)
lines(preds.X[select,'soundTypZ'], preds.Y[select,'ci.u'], col='gray')
lines(preds.X[select,'soundTypZ'], preds.Y[select,'ci.l'], col='gray')
mtext('Image Fit to Sound (z-scores)',side=1,outer=TRUE,padj=-0.2,cex=1.2)
