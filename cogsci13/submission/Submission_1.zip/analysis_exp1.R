library(languageR)
library(lme4)
library(plyr)
library(ggplot2)
library(doBy)
library(AICcmodavg)
source('~/Documents/Apps/CogSci/Submission_2013/helperFunctions-withinSubjErrors.R')

#' ###################
#' Norming data:
#' Predict norming ratings (sound, label) from picture type
#' ###################
normDatFile <- "~/Documents/Apps/CogSci/Submission_2013/data_exp1_norming.csv"
normDat <- read.csv(file=normDatFile,header=TRUE)
describeBy(normDat[,c('meanTypSounds','meanTypLabels')],group=normDat$objType)

summary(lm(meanTypSounds ~ objType, data = normDat))
summary(lm(meanTypLabels ~ objType, data = normDat))
# I don't think this is the correct analysis. How many subjects in the norming study?

#' #################
#' Experiment 1 Data
#' #################
dataFile <- "~/Documents/Apps/CogSci/Submission_2013/data_exp1.csv"
data <- read.csv(file=dataFile,header=TRUE)

## overall accuracy
mean(data$isRight)
sd(data$isRight)

## check for bad images
picFileAccs <- list()
for(file in unique(data$picName)){
  picFileAccs[file] <- mean(data[data$picName==file,'isRight'])
}
picFileAccs = as.data.frame(unlist(picFileAccs))
colnames(picFileAccs) <- 'accuracy'
describe(picFileAccs)
row.names(picFileAccs)[picFileAccs$accuracy < mean(picFileAccs$accuracy) - 3*sd(picFileAccs$accuracy)]
  # no bad pics

## check for bad sound files
soundFileAccs <- list()
for(file in unique(data$soundName)){
  soundFileAccs[file] <- mean(data[data$soundName==file,'isRight'])
}
soundFileAccs = as.data.frame(unlist(soundFileAccs))
colnames(soundFileAccs) <- 'accuracy'
describe(soundFileAccs)
row.names(soundFileAccs)[soundFileAccs$accuracy < mean(soundFileAccs$accuracy) -
                           3*sd(soundFileAccs$accuracy)]
  # bad sound files: river_sound
mean(data[data$soundName=='river_sound','isRight']) # 
length(data[data$soundName=='river_sound','isRight'])/length(data$isRight) # % trials removed

## check for bad subjs
subjAccs <- list()
for(subj in unique(data$subjCode)){
  subjAccs[subj] <- mean(data[data$subjCode==subj,'isRight'])
}
subjAccs = as.data.frame(unlist(subjAccs))
colnames(subjAccs) <- 'accuracy'
describe(subjAccs)
row.names(subjAccs)[subjAccs$accuracy < mean(subjAccs$accuracy) - 3*sd(subjAccs$accuracy)]
  # no bad subjs

## subset the full data
sum(is.na(data[data$isRight == 1,'latency']))/length(data$latency) # < 4% of trials thrown (<250 or >1500)
df <- na.omit(subset(data, data$isValid == 1)) # don't throw any trials by stimuli

#' #####
#' MOD1:
#' #####

## predict latency from picType (sound or silent) and cueType (sound or label)
## model comparison for random effects
MOD1A <- lmer(latency ~ picType * cueType + (1|subjCode), data = df)
MOD1B <- lmer(latency ~ picType * cueType + (1|subjCode) + (1|picCategory), data = df)
dotplot(ranef(MOD1B,postVar=TRUE)) # look at random effects
anova(MOD1A,MOD1B) # do I report this to justify the picCategory random effects?

## rename chosen model as MOD1
MOD1 <- MOD1B

## overall efects
summary(MOD1)
anova(MOD1)

## generate p-vals
set.seed(101)
mcmc.mod1 <- pvals.fnc(MOD1, nsim=1000, withMCMC=TRUE)
mcmc.mod1$fixed

## calculate means to report main effects in text
predsByCue <- summarySEwithin(data = df, measurevar = 'latency',
                              betweenvars = NULL, withinvars = 'cueType', idvar = 'subjCode')
predsByPic <- summarySEwithin(data = df, measurevar = 'latency',
                              betweenvars = NULL, withinvars = 'picType', idvar = 'subjCode')

## investigate simple effect of picture type for label cues
df$cueType.label = ifelse(df$cueType == 'label', 0, 1)
MOD1.label <- lmer(latency ~ picType * cueType.label + (1|subjCode) + (1|picCategory), data = df)
summary(MOD1.label)
set.seed(101)
mcmc.mod1.label <- pvals.fnc(MOD1.label, nsim=1000, withMCMC=TRUE)
mcmc.mod1.label$fixed # effect of picture type for label cues

## investigate simple effect of picture type for sound cues
df$cueType.sound = ifelse(df$cueType == 'sound', 0, 1)
MOD1.sound <- lmer(latency ~ picType * cueType.sound + (1|subjCode) + (1|picCategory), data = df)
summary(MOD1.sound)
set.seed(101)
mcmc.mod1.sound <- pvals.fnc(MOD1.sound, nsim=1000, withMCMC=TRUE)
mcmc.mod1.sound$fixed # no effect of picture type for sound cues

#' ##########
#' Figure 2A:
#' ##########
df$cueTypeR  <- factor(df$cueType, levels=rev(levels(df$cueType)))
df$picTypeR  <- factor(df$picType, levels=rev(levels(df$picType)))

## generate predictions and errors
preds.base <- summarySEwithin(data = df, measurevar = 'latency',
                         betweenvars = NULL, withinvars = c('picTypeR','cueTypeR'), idvar = 'subjCode')

ggplot(preds.base, aes(x=picTypeR, y=latencyNormed, fill=cueTypeR)) +
  geom_bar(width = 0.6, position = position_dodge(width=0.7), color="black", stat='identity') +
  geom_errorbar(position=position_dodge(.7), width=.25, aes(ymin=latencyNormed-ci, ymax=latencyNormed+ci)) +
  coord_cartesian(ylim=c(500,700)) +
  scale_fill_manual('Auditory Cue', labels = c('Natural Sound','Label'), values=c('blue','red')) +
  scale_y_continuous('Response Latency (msec)',breaks=seq(500,700,by=50)) +
  scale_x_discrete('Picture Type', labels = c('Silent' = 'Rest','Sound'='Action')) +
  theme_bw(base_size=24) +
  theme(legend.position = c(0.5,0.9), legend.direction = "horizontal") + 
  guides(fill=guide_legend(title=NULL))

#' ##########
#' MOD.catTyp:
#' ##########
MOD.catTyp <- lmer(latency ~ labelTypZ * cueType + (1|subjCode) + (1|picCategory), data = df)
summary(MOD.catTyp)
anova(MOD.catTyp)
set.seed(101)
mcmc.catTyp <- pvals.fnc(MOD.catTyp, nsim=1000, withMCMC=TRUE)
mcmc.catTyp$fixed # effect of category typicality for label cues

df$cueTypeR  <- factor(df$cueType, levels=rev(levels(df$cueType)))
MOD.catTypR <- lmer(latency ~ labelTypZ * cueTypeR + (1|subjCode) + (1|picCategory), data = df)
summary(MOD.catTypR)
anova(MOD.catTypR)
set.seed(101)
mcmc.catTypR <- pvals.fnc(MOD.catTypR, nsim=1000, withMCMC=TRUE)
mcmc.catTypR$fixed # effect of category typicality for label cues

#' ##########
#' MOD.soundTyp:
#' ##########
MOD.soundTyp <- lmer(latency ~ soundTypZ * cueType + (1|subjCode) + (1|picCategory), data = df)
summary(MOD.soundTyp)
anova(MOD.soundTyp)
set.seed(101)
mcmc.soundTyp <- pvals.fnc(MOD.soundTyp, nsim=1000, withMCMC=TRUE)
mcmc.soundTyp$fixed # no effect of sound production for sound cues

#' ##########
#' Figure 2B:
#' ##########
describe(df[,c('labelTypZ','soundTypZ')]) # determine range of z-scores (x-axis)

## set up the graphing space
par(mfrow=c(1,2), mar=c(2,0,2,1)+0.1, oma=c(2,5,2,0)+0.1)

## predictions for MOD.catTyp (left graph)
preds.X <- expand.grid(labelTypZ = seq(-3.2,1.5,by=0.5),
                       cueType = c('label','sound'))
preds.Y <- as.data.frame(predictSE.mer(mod=MOD.catTyp, newdata=preds.X, 
                                            type='link', print.matrix=TRUE))
preds.Y$ci.u <- preds.Y$fit + preds.Y$se.fit
preds.Y$ci.l <- preds.Y$fit - preds.Y$se.fit

## LEFT GRAPH: Category Typicality
plot(x=df$labelTypZ, y=df$latency, type='n',
     ylim=range(500,700), yaxt='n', xlim=range(-3.2,1.5), xaxt='n', bty='n')
axis(side=2,at=seq(500,700,by=50),labels=seq(500,700,by=50),tick=TRUE,line=1)
axis(side=1,at=c(-3.0,-1.5,0,1.5),labels=c(-3.0,-1.5,0,1.5),tick=TRUE,line=NA)
rug(df$labelTypZ)

select <- (preds.X$cueType == 'sound')
lines(preds.X[select,'labelTypZ'], preds.Y[select,'fit'], col='blue', lwd=2, lty=2)
lines(preds.X[select,'labelTypZ'], preds.Y[select,'ci.u'], col='gray')
lines(preds.X[select,'labelTypZ'], preds.Y[select,'ci.l'], col='gray')

select <- (preds.X$cueType == 'label')
lines(preds.X[select,'labelTypZ'], preds.Y[select,'fit'], col='red', lwd=2)
lines(preds.X[select,'labelTypZ'], preds.Y[select,'ci.u'], col='gray')
lines(preds.X[select,'labelTypZ'], preds.Y[select,'ci.l'], col='gray')
mtext('Response Latency (msec)',side=2,padj=-4.5,cex=1.2)
mtext('Category Typicality',side=1,padj=3,cex=1.2)


## predictions for MOD.soundTyp (right graph)
preds.X <- expand.grid(soundTypZ = seq(-3.2,1.5,by=0.5),
                       cueType = c('label','sound'))

preds.Y <- as.data.frame(predictSE.mer(mod=MOD.soundTyp, newdata=preds.X, 
                                       type='link', print.matrix=TRUE))
preds.Y$ci.u <- preds.Y$fit + preds.Y$se.fit
preds.Y$ci.l <- preds.Y$fit - preds.Y$se.fit

## RIGHT GRAPH: Sound Typicality
plot(x=df$labelTypZ, y=df$latency, type='n',
     ylim=range(500,700), yaxt='n', xlim=range(-3.2,1.5), xaxt='n', bty='n')
axis(side=2,at=seq(500,700,by=50),labels=seq(500,700,by=50),tick=TRUE,line=NA)
axis(side=1,at=c(-3.0,-1.5,0,1.5),labels=c(-3.0,-1.5,0,1.5),tick=TRUE,line=NA)
rug(df$soundTypZ)

legend("bottomright",inset=0.1, title="Auditory Cue",
       c('Natural Sound','Label'), col=c('blue','red'), horiz=FALSE,
       lty=c(2,1), lwd=c(3,3), bty='n')

select <- (preds.X$cueType == 'sound')
lines(preds.X[select,'soundTypZ'], preds.Y[select,'fit'], col='blue', lwd=2, lty=2)
lines(preds.X[select,'soundTypZ'], preds.Y[select,'ci.u'], col='gray')
lines(preds.X[select,'soundTypZ'], preds.Y[select,'ci.l'], col='gray')

select <- (preds.X$cueType == 'label')
lines(preds.X[select,'soundTypZ'], preds.Y[select,'fit'], col='red', lwd=2)
lines(preds.X[select,'soundTypZ'], preds.Y[select,'ci.u'], col='gray')
lines(preds.X[select,'soundTypZ'], preds.Y[select,'ci.l'], col='gray')
mtext('Sound Match',side=1,padj=3,cex=1.2)
mtext('1 Second Delay',side=3,outer=TRUE,padj=1.5,cex=1.2)


